#ifndef  _STDIO_H  
#define  _STDIO_H  
  
char *strcat(char *a, char *b);
int strcmp(char *s1, char *s2);
char *strcpy(u32 *s1, u32 *s2);
#endif  