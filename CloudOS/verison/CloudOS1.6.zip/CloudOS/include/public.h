#ifndef CHAPTER3_INCLUDE_COMMON_H_
#define CHAPTER3_INCLUDE_COMMON_H_


void start();
extern void in_byte();
extern void out_byte();
extern void disp_str();
extern void memcpy();

#endif /* CHAPTER3_INCLUDE_COMMON_H_ */